package Edit.EducacionIT_61772;

import org.testng.annotations.Test;

public class Clase1 {
	// Atributos / variables
	String mensaje = "Hola Clase de Automatización!";
	
	// Método de prueba
	@Test
	public void probarJava() {
		// Imprimir un mensaje en la consola
		System.out.println(mensaje);
		
		/**
		 * Comentario 
		 * tiene 
		 * dos líneas
		 */
	}
}
